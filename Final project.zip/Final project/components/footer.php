<footer class="footer">

   &copy; copyright @ <?= date('Y'); ?> by <span>GROUP12/Project_WWW</span> | all rights reserved!

</footer>